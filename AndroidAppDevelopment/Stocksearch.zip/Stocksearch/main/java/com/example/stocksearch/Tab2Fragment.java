package com.example.stocksearch;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 */
public class Tab2Fragment extends Fragment {

    public Tab2Fragment() {
        // Required empty public constructor
    }

    View v;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Bundle b2 = getArguments();
        if (b2 != null) {
            String symstring = b2.getString("Esymbol");   // full file name
            String[] parts = symstring.split("-"); // String array, each element is text between dots
            String beforeFirstDot = parts[0];
            final String symbol = beforeFirstDot;
            v = inflater.inflate(R.layout.fragment_tab2, container, false);

            final WebView myWebView = (WebView) v.findViewById(R.id.webview);
            WebSettings webSettings = myWebView.getSettings();
            webSettings.setJavaScriptEnabled(true);
            myWebView.loadUrl("file:///android_asset/Hist.html");
            myWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    myWebView.loadUrl("javascript:showhist('" + symbol + "')");
                }
                @Override
                public void onReceivedHttpError (WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                    myWebView.setVisibility(View.GONE);
                    TextView texterror = (TextView) v.findViewById(R.id.texterrorhist);
                    texterror.setVisibility(View.VISIBLE);
                    Toast.makeText(getActivity(), "Error! Cant get Historical Charts Data", Toast.LENGTH_LONG).show();
                }
                @Override
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    myWebView.setVisibility(View.GONE);
                    TextView texterror = (TextView) v.findViewById(R.id.texterrorhist);
                    texterror.setVisibility(View.VISIBLE);
                    Toast.makeText(getActivity(), "Error! Cant get Historical Charts Data", Toast.LENGTH_LONG).show();

                }

            });



//        WebView myWebView = (WebView) v.findViewById(R.id.webview);
//        myWebView.loadUrl("http://homework8vpravi-env.us-east-1.elasticbeanstalk.com/HW8.html");

//        // Enable Javascript
//        WebSettings webSettings = myWebView.getSettings();
//        webSettings.setJavaScriptEnabled(true);
//
//        // Force links and redirects to open in the WebView instead of in a browser
//        myWebView.setWebViewClient(new WebViewClient());

        }

//    class RetrieveFeedTask2 extends AsyncTask<Void, Void, String> {
//
//        private Exception exception;
//
//        protected void onPreExecute() {
//
//        }
//
//        protected String doInBackground(Void... urls) {
//
//            try {
//                URL url = new URL(API_URL+symbol+API_KEY);
//                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
//                try {
//                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
//                    StringBuilder stringBuilder = new StringBuilder();
//                    String line;
//                    while ((line = bufferedReader.readLine()) != null) {
//                        stringBuilder.append(line).append("\n");
//                    }
//                    bufferedReader.close();
//                    return stringBuilder.toString();
//                } finally {
//                    urlConnection.disconnect();
//                }
//            } catch (Exception e) {
////                Log.e("ERROR", e.getMessage(), e);
//                return null;
//            }
//        }
//
//        protected void onPostExecute(String response) {
//            if (response == null) {
//                response = "THERE WAS AN ERROR";
//            }
//            try {
//
//                JSONObject object = (JSONObject) new JSONTokener(response).nextValue();
//                JSONObject Timeseriesvalues = object.getJSONObject("Time Series (Daily)");
//                JSONArray timekeys = Timeseriesvalues.names();
//                int jj = Timeseriesvalues.length();
//                for (int y = 0; y < jj; y++) {
//                    String key = timekeys.get(y).toString();
//                    JSONObject LastSession = Timeseriesvalues.getJSONObject(key);
//                    price.put(LastSession.getString("4. close"));
//                    dates.put(key);
//                }
//
//                final WebView myWebView = (WebView) v.findViewById(R.id.webview);
//                WebSettings webSettings = myWebView.getSettings();
//                webSettings.setJavaScriptEnabled(true);
//                myWebView.loadUrl("file:///android_asset/Hist.html");
//                myWebView.setWebViewClient(new WebViewClient()
//                {
//                    @Override
//                    public void onPageFinished(WebView view, String url) {
//                        myWebView.loadUrl("javascript:loadhistgraph('"+gson.toJson(price)+"','"+symbol+"')");
//                    }
//                });
//
//
//            } catch (JSONException e) {
//                TextView texterror = (TextView)v.findViewById(R.id.texterror);
//                texterror.setText(response);
//                texterror.setVisibility(View.VISIBLE);
//            }
//        }
//    }
        return v;
    }

}
