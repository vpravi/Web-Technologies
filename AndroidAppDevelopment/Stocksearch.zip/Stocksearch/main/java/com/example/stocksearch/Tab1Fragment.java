package com.example.stocksearch;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import static android.app.Activity.RESULT_OK;
import static android.content.ContentValues.TAG;



/**
 * A simple {@link Fragment} subclass.
 */
public class Tab1Fragment extends Fragment {


    View v;
    private RequestQueue mRequestQueue;
    private StringRequest stringRequest;
    static JSONArray Price = null;
    static JSONArray Dates = null;
    static int pos;
    ProgressBar progressBar;
    TableLayout table;
    WebView indicators;
    static WebView myWebView;
    String jsonText;
    Gson gson = new Gson();
    ImageButton imgButton;
    boolean isFav = false;
    Button btn;
//    public static final String PREFS_NAME = "MyPrefsFile";
//    SharedPreferences prefs;
//    private static SharedPreferences getPrefs(Context context) {
//        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
//    }
//
//    public static void setSymbol(Context context, String input) {
//        SharedPreferences.Editor editor = getPrefs(context).edit();
//        editor.putString(symbol,input);
//        editor.commit();
//    }

    Context mContext;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Bundle b2 = getArguments();
        if (b2 != null){
//            Toolbar toolbar = (Toolbar)v.findViewById(R.id.toolbar);
//                setSupportActionBar(toolbar);
            String symstring = b2.getString("Esymbol");   // full file name
            String[] parts = symstring.split("-"); // String array, each element is text between dots
            String beforeFirstDot = parts[0];
            final String symbol = beforeFirstDot;
            String API_final = "http://homework8vpravi-env.us-east-1.elasticbeanstalk.com/index.php?searchsymbol="+symbol;
            v = inflater.inflate(R.layout.fragment_tab1, container, false);
            btn = (Button) v.findViewById(R.id.changebtn);
            btn.setEnabled(false);
            progressBar = (ProgressBar) v.findViewById(R.id.progressBar);
            table = (TableLayout) v.findViewById(R.id.maintable);
            indicators = (WebView) v.findViewById(R.id.webviewindicators);
            progressBar.setVisibility(View.VISIBLE);
            table.setVisibility(View.GONE);
            indicators.setVisibility(View.GONE);
            mContext = getActivity().getApplicationContext();
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getActivity());
            Map<String,?> check = sharedPref.getAll();
            Set<String> checklist = check.keySet();
            imgButton = (ImageButton)v.findViewById(R.id.buttonfav);
            List<String> nameList = new ArrayList<String>(checklist);

            if (nameList.contains(symbol)){
                imgButton.setImageResource(R.drawable.filledstar);
            }else{
                imgButton.setImageResource(R.drawable.emptystar);
            }
            final List<String> row = new ArrayList<String>();
            Spinner spinner = (Spinner) v.findViewById(R.id.spinner);
            // Create an ArrayAdapter using the string array and a default spinner layout
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(),
                    R.array.indicators_array, android.R.layout.simple_spinner_item);
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            // Apply the adapter to the spinner
            pos = 30;
            spinner.setAdapter(adapter);
            final String[] indicators_array = {"price", "sma", "ema", "rsi", "cci", "adx", "stoch", "bbands", "macd"};
            spinner.setOnItemSelectedListener(
                    new AdapterView.OnItemSelectedListener() {
                        public void onItemSelected(
                                AdapterView<?> parent, View view, final int position, long id) {
                            pos = position;
                            btn.setEnabled(true);
                        }

                        public void onNothingSelected(AdapterView<?> parent) {
                        }
                    });


            btn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    WebSettings webSettings = myWebView.getSettings();
                    webSettings.setJavaScriptEnabled(true);
                    myWebView.loadUrl("file:///android_asset/Indicators.html");
                    myWebView.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(WebView view, String url) {
                            final String valz = indicators_array[pos];
                            if (valz == "price") {
                                myWebView.loadUrl("javascript:loadpricegraph('" + symbol + "')");
                            } else {
                                myWebView.loadUrl("javascript:showindicator('" + symbol + "','" + valz + "')");
                            }
                        }
                    });

                    btn.setEnabled(false);
                }
            });



            mRequestQueue = Singleton.getInstance(getActivity().getApplicationContext()).getRequestQueue(getActivity().getApplicationContext());
            stringRequest = new StringRequest(Request.Method.GET, API_final, new Response.Listener<String>() {
                public void onResponse(String response) {
//
                    try {
                        progressBar.setVisibility(View.GONE);
                        JSONObject object = (JSONObject) new JSONTokener(response).nextValue();
                        JSONObject header = object.getJSONObject("Meta Data");
                        String symbol = header.getString("2. Symbol");
                        final String val = symbol;
                        JSONObject Timeseriesvalues = object.getJSONObject("Time Series (Daily)");
                        JSONArray timekeys = Timeseriesvalues.names();
                        String key = timekeys.get(0).toString();
                        String oldkey = timekeys.get(1).toString();
                        JSONObject lastsession = Timeseriesvalues.getJSONObject(key);
                        JSONObject previoussession = Timeseriesvalues.getJSONObject(oldkey);
                        String timestamp = header.getString("3. Last Refreshed");
                        String open = lastsession.getString("1. open");
                        String lastprice = previoussession.getString("4. close");
                        String close = lastsession.getString("4. close");
                        String volume = lastsession.getString("5. volume");
                        String low = lastsession.getString("3. low");
                        String high = lastsession.getString("2. high");
                        Double newclose = Math.round((Double.valueOf(close)) * 100.0) / 100.0;
                        Double newlprice = Math.round((Double.valueOf(lastprice)) * 100.0) / 100.0;
                        String finalclose = Double.toString(newclose);
                        String finalprice = Double.toString(newlprice);
                        Double Change = newclose - newlprice;
                        Double Changepercent = (Change / newclose) * 100.0;
                        String finalchange = Double.toString(Math.round((Change) * 100.0) / 100.0);
                        String finalchangeperc = Double.toString(Math.round((Changepercent) * 100.0) / 100.0);
                        String finalopen = Double.toString(Math.round((Double.valueOf(open)) * 100.0) / 100.0);
                        String newlow = Double.toString(Math.round((Double.valueOf(low)) * 100.0) / 100.0);
                        String newhigh = Double.toString(Math.round((Double.valueOf(high)) * 100.0) / 100.0);
                        String finalrange = newlow + " - " + newhigh;
                        String Change_percent = finalchange + " (" + finalchangeperc + ")";
                        TextView OpenTxt = (TextView) v.findViewById(R.id.open);
                        OpenTxt.setText(finalopen);
                        TextView SymbolTxt = (TextView) v.findViewById(R.id.symbol);
                        SymbolTxt.setText(symbol);
                        TextView TimestampTxt = (TextView) v.findViewById(R.id.timestamp);
                        TimestampTxt.setText(timestamp);
                        TextView LastPTxt = (TextView) v.findViewById(R.id.lastprice);
                        LastPTxt.setText(finalprice);
                        TextView CloseTxt = (TextView) v.findViewById(R.id.close);
                        CloseTxt.setText(finalclose);
                        TextView VolumeTxt = (TextView) v.findViewById(R.id.volume);
                        VolumeTxt.setText(volume);
                        ImageView arrowimg = (ImageView)v.findViewById(R.id.arrowicon);
                        if(Change>0) {
                            TextView ChangeTxt = (TextView) v.findViewById(R.id.change);
                            ChangeTxt.setText(Change_percent);
                            ChangeTxt.setTextColor(Color.GREEN);
                            arrowimg.setImageResource(R.drawable.green_arrow_up);
                        }else if(Change<0){
                            TextView ChangeTxt = (TextView) v.findViewById(R.id.change);
                            ChangeTxt.setText(Change_percent);
                            ChangeTxt.setTextColor(Color.RED);
                            arrowimg.setImageResource(R.drawable.red_down);
                        }
                        TextView DaysRangeTxt = (TextView) v.findViewById(R.id.range);
                        DaysRangeTxt.setText(finalrange);
                        table.setVisibility(View.VISIBLE);
                        myWebView = (WebView) v.findViewById(R.id.webviewindicators);
                        WebSettings webSettings = myWebView.getSettings();
                        webSettings.setJavaScriptEnabled(true);
                        myWebView.loadUrl("file:///android_asset/Indicators.html");
                        btn.setEnabled(false);
                        myWebView.setWebViewClient(new WebViewClient() {
                            @Override
                            public void onPageFinished(WebView view, String url) {
                                myWebView.loadUrl("javascript:loadpricegraph('" + val + "')");
                            }
                        });
                        ImageView Arrowimg = (ImageView)v.findViewById(R.id.arrowicon);
                        Arrowimg.setVisibility(View.VISIBLE);
                        indicators.setVisibility(View.VISIBLE);
                        String[] row = {symbol, finalprice, Change_percent,finalchange};
                        jsonText = gson.toJson(row);
//                    setSymbol(mContext,finalprice);
//
//                    TextView name = (TextView)v.findViewById(R.id.random);


                    } catch (JSONException e) {
                        TextView texterror = (TextView) v.findViewById(R.id.texterror);
                        texterror.setVisibility(View.VISIBLE);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                        TextView texterror = (TextView) v.findViewById(R.id.texterror);
                        texterror.setVisibility(View.VISIBLE);
                        progressBar.setVisibility(View.GONE);
                    }
                }
            });
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    10000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            mRequestQueue.add(stringRequest);
            final ImageButton queryButton = (ImageButton) v.findViewById(R.id.buttonfav);
            queryButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    if (isFav){

//                    }
//                    else{
//                        queryButton.setImageResource(R.drawable.emptystar);
//                    }
                    Intent intent = new Intent();
//                    intent.putExtra("clickeditem",symbol);
                    getActivity().setResult(RESULT_OK, intent);
                    SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getActivity());
                    SharedPreferences.Editor editor = sharedPref.edit();
                    Map<String,?> keys = sharedPref.getAll();
                    Set<String> globkeys = keys.keySet();
                    List<String> nameList = new ArrayList<String>(globkeys);
                    if (jsonText != null){
                    if (nameList.contains(symbol)){
                        queryButton.setImageResource(R.drawable.emptystar);
                        editor.remove(symbol);
                        editor.apply();
                    }else{

                        queryButton.setImageResource(R.drawable.filledstar);
                        editor.putString(symbol, jsonText);
                        editor.commit();
                    }}
                }
            });
        }

        return v;
    }
}

