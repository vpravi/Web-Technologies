package com.example.stocksearch;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import static android.content.ContentValues.TAG;


public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.stocksearch.MESSAGE";

    private RequestQueue mRequestQueue;
    private StringRequest stringRequest;
    ArrayAdapter adapter;
    TextView name;
    String[] symbols;
    String API_autocomplete;
    static Integer posorder;
    static Integer possort;
    SharedPreferences sharedPref;
    Gson gson = new Gson();
    Spinner spinner;
//    String[] globsym;
//    String[] globprice;
//    String[] globchange;
    Set<String> globkeys;
    Set<String> globkeys1;
    AutoCompleteTextView text;
//    CustomFavAdapter favadapter;
    final String[] order_array = {"OrderBy", "Ascending", "Descending"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        text = (AutoCompleteTextView)findViewById(R.id.autoCompleteTextView);
        AutoCompleteAdapter autoadapter = new AutoCompleteAdapter(getApplicationContext(),android.R.layout.simple_dropdown_item_1line);
        text.setAdapter(autoadapter);
        text.setThreshold(1);

        final String[] sort_array = {"SortBy", "Symbol", "Price", "Change"};
        spinner = (Spinner)findViewById(R.id.order);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                R.array.orderBy_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        Spinner spinner1 = (Spinner)findViewById(R.id.sort);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(getApplicationContext(),
                R.array.sortBy_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner1.setAdapter(adapter1);

        spinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(
                            AdapterView<?> parent, View view, final int position, long id) {
                        posorder = position;
                        sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                        Map<String,?> keys = sharedPref.getAll();
                        if(possort != null ) {
                            String val = sort_array[possort];
                            if(sort_array[possort] == "Symbol") {
                                ArrayList<String> sortsymList = new ArrayList<String>();
                                for (Map.Entry<String, ?> entry : keys.entrySet()) {
                                    String key = entry.getKey();
                                    String value = entry.getValue().toString();
                                    String[] text = gson.fromJson(value, String[].class);
                                    sortsymList.add(text[0]);
                                }
                                if (order_array[posorder] == "Ascending") {
                                    Collections.sort(sortsymList);
                                } else if (order_array[posorder] == "Descending") {
                                    Collections.sort(sortsymList);
                                    Collections.reverse(sortsymList);
                                }
                                ArrayList<String> symList = new ArrayList<String>();
                                ArrayList<String> priceList = new ArrayList<String>();
                                ArrayList<String> changeList = new ArrayList<String>();
                                String[] symarray;
                                String[] pricearray;
                                String[] changearray;
                                for (int counter = 0; counter < sortsymList.size(); counter++) {
                                    String val1 = keys.get(sortsymList.get(counter)).toString();
                                    String[] text = gson.fromJson(val1,String[].class);
                                    symList.add(text[0]);
                                    priceList.add(text[1]);
                                    changeList.add(text[2]);
                                }
                                symarray = symList.toArray(new String[symList.size()]);
                                pricearray = priceList.toArray(new String[priceList.size()]);
                                changearray = changeList.toArray(new String[changeList.size()]);
                                CustomFavAdapter favadapter = new CustomFavAdapter(getApplicationContext(),symarray,pricearray,changearray);
                                ListView listView = (ListView)findViewById(R.id.favlist);
                                listView.setAdapter(favadapter);
//                         Log.d("map values",order_array[pos]);
                            }else if(sort_array[possort] == "Price") {
                                ArrayList<Float> sortpriceList = new ArrayList<Float>();
                                HashMap<String, Object> newprice = new HashMap<String, Object>();
                                for (Map.Entry<String, ?> entry : keys.entrySet()) {
                                    String key = entry.getKey();
                                    String value = entry.getValue().toString();
                                    String[] text = gson.fromJson(value, String[].class);
                                    newprice.put(text[1], value);
                                    sortpriceList.add(Float.valueOf(text[1]));
                                }
                                if (order_array[posorder] == "Ascending") {
                                    Collections.sort(sortpriceList);
                                } else if (order_array[posorder] == "Descending") {
                                    Collections.sort(sortpriceList);
                                    Collections.reverse(sortpriceList);
                                }
                                ArrayList<String> symList = new ArrayList<String>();
                                ArrayList<String> priceList = new ArrayList<String>();
                                ArrayList<String> changeList = new ArrayList<String>();
                                String[] symarray;
                                String[] pricearray;
                                String[] changearray;
                                for (int counter = 0; counter < sortpriceList.size(); counter++) {
                                    String val1 = newprice.get(sortpriceList.get(counter).toString()).toString();
                                    String[] text = gson.fromJson(val1, String[].class);
                                    symList.add(text[0]);
                                    priceList.add(text[1]);
                                    changeList.add(text[2]);
                                }
                                symarray = symList.toArray(new String[symList.size()]);
                                pricearray = priceList.toArray(new String[priceList.size()]);
                                changearray = changeList.toArray(new String[changeList.size()]);
                                CustomFavAdapter favadapter = new CustomFavAdapter(getApplicationContext(), symarray, pricearray, changearray);
                                ListView listView = (ListView) findViewById(R.id.favlist);
                                listView.setAdapter(favadapter);
//                         Log.d("map values",order_array[pos])
                            } else if (sort_array[possort] == "Change") {
                                ArrayList<Float> sortchangeList = new ArrayList<Float>();
                                HashMap<String, Object> newchange = new HashMap<String, Object>();
                                for (Map.Entry<String, ?> entry : keys.entrySet()) {
                                    String key = entry.getKey();
                                    String value = entry.getValue().toString();
                                    String[] text = gson.fromJson(value, String[].class);
                                    newchange.put(text[3], value);
                                    sortchangeList.add(Float.valueOf(text[3]));
                                }
                                if (order_array[posorder] == "Ascending") {
                                    Collections.sort(sortchangeList);
                                } else if (order_array[posorder] == "Descending") {
                                    Collections.sort(sortchangeList);
                                    Collections.reverse(sortchangeList);
                                }
                                ArrayList<String> symList = new ArrayList<String>();
                                ArrayList<String> priceList = new ArrayList<String>();
                                ArrayList<String> changeList = new ArrayList<String>();
                                String[] symarray;
                                String[] pricearray;
                                String[] changearray;
                                for (int counter = 0; counter < sortchangeList.size(); counter++) {
                                    String val1 = newchange.get(sortchangeList.get(counter).toString()).toString();
                                    String[] text = gson.fromJson(val1, String[].class);
                                    symList.add(text[0]);
                                    priceList.add(text[1]);
                                    changeList.add(text[2]);
                                }
                                symarray = symList.toArray(new String[symList.size()]);
                                pricearray = priceList.toArray(new String[priceList.size()]);
                                changearray = changeList.toArray(new String[changeList.size()]);
                                CustomFavAdapter favadapter = new CustomFavAdapter(getApplicationContext(), symarray, pricearray, changearray);
                                ListView listView = (ListView) findViewById(R.id.favlist);
                                listView.setAdapter(favadapter);
//                         Log.d("map values",order_array[pos])
                            }
                        }
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

        spinner1.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(
                            AdapterView<?> parent, View view, final int position, long id) {
                        possort = position;
                        sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                        Map<String, ?> keys = sharedPref.getAll();
                        if (posorder != null) {
                            if (sort_array[possort] == "Symbol") {
                                ArrayList<String> sortsymList = new ArrayList<String>();
                                for (Map.Entry<String, ?> entry : keys.entrySet()) {
                                    String key = entry.getKey();
                                    String value = entry.getValue().toString();
                                    String[] text = gson.fromJson(value, String[].class);
                                    sortsymList.add(text[0]);
                                }
                                if (order_array[posorder] == "Ascending") {
                                    Collections.sort(sortsymList);
                                } else if (order_array[posorder] == "Descending") {
                                    Collections.sort(sortsymList);
                                    Collections.reverse(sortsymList);
                                }
                                ArrayList<String> symList = new ArrayList<String>();
                                ArrayList<String> priceList = new ArrayList<String>();
                                ArrayList<String> changeList = new ArrayList<String>();
                                String[] symarray;
                                String[] pricearray;
                                String[] changearray;
                                for (int counter = 0; counter < sortsymList.size(); counter++) {
                                    String val1 = keys.get(sortsymList.get(counter)).toString();
                                    String[] text = gson.fromJson(val1, String[].class);
                                    symList.add(text[0]);
                                    priceList.add(text[1]);
                                    changeList.add(text[2]);
                                }
                                symarray = symList.toArray(new String[symList.size()]);
                                pricearray = priceList.toArray(new String[priceList.size()]);
                                changearray = changeList.toArray(new String[changeList.size()]);
                                CustomFavAdapter favadapter = new CustomFavAdapter(getApplicationContext(), symarray, pricearray, changearray);
                                ListView listView = (ListView) findViewById(R.id.favlist);
                                listView.setAdapter(favadapter);
//                         Log.d("map values",order_array[pos]);
                            } else if (sort_array[possort] == "Price") {
                                ArrayList<Float> sortpriceList = new ArrayList<Float>();
                                HashMap<String, Object> newprice = new HashMap<String, Object>();
                                for (Map.Entry<String, ?> entry : keys.entrySet()) {
                                    String key = entry.getKey();
                                    String value = entry.getValue().toString();
                                    String[] text = gson.fromJson(value, String[].class);
                                    newprice.put(text[1], value);
                                    sortpriceList.add(Float.valueOf(text[1]));
                                }
                                if (order_array[posorder] == "Ascending") {
                                    Collections.sort(sortpriceList);
                                } else if (order_array[posorder] == "Descending") {
                                    Collections.sort(sortpriceList);
                                    Collections.reverse(sortpriceList);
                                }
                                ArrayList<String> symList = new ArrayList<String>();
                                ArrayList<String> priceList = new ArrayList<String>();
                                ArrayList<String> changeList = new ArrayList<String>();
                                String[] symarray;
                                String[] pricearray;
                                String[] changearray;
                                for (int counter = 0; counter < sortpriceList.size(); counter++) {
                                    String val1 = newprice.get(sortpriceList.get(counter).toString()).toString();
                                    String[] text = gson.fromJson(val1, String[].class);
                                    symList.add(text[0]);
                                    priceList.add(text[1]);
                                    changeList.add(text[2]);
                                }
                                symarray = symList.toArray(new String[symList.size()]);
                                pricearray = priceList.toArray(new String[priceList.size()]);
                                changearray = changeList.toArray(new String[changeList.size()]);
                                CustomFavAdapter favadapter = new CustomFavAdapter(getApplicationContext(), symarray, pricearray, changearray);
                                ListView listView = (ListView) findViewById(R.id.favlist);
                                listView.setAdapter(favadapter);
//                         Log.d("map values",order_array[pos])
                            } else if (sort_array[possort] == "Change") {
                                ArrayList<Float> sortchangeList = new ArrayList<Float>();
                                HashMap<String, Object> newchange = new HashMap<String, Object>();
                                for (Map.Entry<String, ?> entry : keys.entrySet()) {
                                    String key = entry.getKey();
                                    String value = entry.getValue().toString();
                                    String[] text = gson.fromJson(value, String[].class);
                                    newchange.put(text[3], value);
                                    sortchangeList.add(Float.valueOf(text[3]));
                                }
                                if (order_array[posorder] == "Ascending") {
                                    Collections.sort(sortchangeList);
                                } else if (order_array[posorder] == "Descending") {
                                    Collections.sort(sortchangeList);
                                    Collections.reverse(sortchangeList);
                                }
                                ArrayList<String> symList = new ArrayList<String>();
                                ArrayList<String> priceList = new ArrayList<String>();
                                ArrayList<String> changeList = new ArrayList<String>();
                                String[] symarray;
                                String[] pricearray;
                                String[] changearray;
                                for (int counter = 0; counter < sortchangeList.size(); counter++) {
                                    String val1 = newchange.get(sortchangeList.get(counter).toString()).toString();
                                    String[] text = gson.fromJson(val1, String[].class);
                                    symList.add(text[0]);
                                    priceList.add(text[1]);
                                    changeList.add(text[2]);
                                }
                                symarray = symList.toArray(new String[symList.size()]);
                                pricearray = priceList.toArray(new String[priceList.size()]);
                                changearray = changeList.toArray(new String[changeList.size()]);
                                CustomFavAdapter favadapter = new CustomFavAdapter(getApplicationContext(), symarray, pricearray, changearray);
                                ListView listView = (ListView) findViewById(R.id.favlist);
                                listView.setAdapter(favadapter);
//                         Log.d("map values",order_array[pos])
                            }
                        }
                    }

                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

        Button clearButton = (Button) findViewById(R.id.buttonclear);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AutoCompleteTextView txt = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
                txt.setText("");
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {

        if (v.getId() == R.id.favlist) {
            ListView lv = (ListView) v;
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)menuInfo;
            String[] menuitems = getResources().getStringArray(R.array.menu_array);
            for (int i =0;i<menuitems.length;i++){
                menu.add(Menu.NONE,i,i,menuitems[i]);
            }
        }

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int menuindex = item.getItemId();
        String[] menuitems = getResources().getStringArray(R.array.menu_array);
        String each = menuitems[menuindex];
        sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor editor = sharedPref.edit();
        Map<String,?> keys = sharedPref.getAll();
        globkeys = keys.keySet();
        List<String> nameList = new ArrayList<String>(globkeys);
        String val = nameList.get(info.position);
        if(each.equals("Yes")){
            editor.remove(val);
            editor.apply();
            Toast.makeText(getApplicationContext(), "Selected Yes", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(), "Selected No", Toast.LENGTH_SHORT).show();
        }

        sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        Map<String,?> Kkeys = sharedPref.getAll();
        ArrayList<String> symList = new ArrayList<String>();
        ArrayList<String> priceList = new ArrayList<String>();
        ArrayList<String> changeList = new ArrayList<String>();
        String[] symarray;
        String[] pricearray;
        String[] changearray;
        for(Map.Entry<String,?> entry : Kkeys.entrySet()){
            String key = entry.getKey();
            String value = entry.getValue().toString();
            String[] text = gson.fromJson(value,String[].class);
            symList.add(text[0]);
            priceList.add(text[1]);
            changeList.add(text[2]);
//            Log.d("map values",entry.getKey() + ": " +
//                    entry.getValue().toString());
        }

        symarray = symList.toArray(new String[symList.size()]);
        pricearray = priceList.toArray(new String[priceList.size()]);
        changearray = changeList.toArray(new String[changeList.size()]);
//                globsym = symarray;
//                globprice = pricearray;
//                globchange = changearray;
        CustomFavAdapter favadapter = new CustomFavAdapter(getApplicationContext(),symarray,pricearray,changearray);
        ListView listView = (ListView)findViewById(R.id.favlist);
        registerForContextMenu(listView);
        listView.setAdapter(favadapter);


        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2){
            if (resultCode == RESULT_OK) {
                sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String,?> keys = sharedPref.getAll();
                ArrayList<String> symList = new ArrayList<String>();
                ArrayList<String> priceList = new ArrayList<String>();
                ArrayList<String> changeList = new ArrayList<String>();
                String[] symarray;
                String[] pricearray;
                String[] changearray;
                for(Map.Entry<String,?> entry : keys.entrySet()){
                    String key = entry.getKey();
                    String value = entry.getValue().toString();
                    String[] text = gson.fromJson(value,String[].class);
                    symList.add(text[0]);
                    priceList.add(text[1]);
                    changeList.add(text[2]);
//            Log.d("map values",entry.getKey() + ": " +
//                    entry.getValue().toString());
                }

                symarray = symList.toArray(new String[symList.size()]);
                pricearray = priceList.toArray(new String[priceList.size()]);
                changearray = changeList.toArray(new String[changeList.size()]);
//                globsym = symarray;
//                globprice = pricearray;
//                globchange = changearray;
                CustomFavAdapter favadapter = new CustomFavAdapter(getApplicationContext(),symarray,pricearray,changearray);
                ListView listView = (ListView)findViewById(R.id.favlist);
                registerForContextMenu(listView);
                listView.setAdapter(favadapter);

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                        SharedPreferences.Editor editor = sharedPref.edit();
                        Map<String,?> keys = sharedPref.getAll();
                        globkeys1 = keys.keySet();
                        List<String> nameList = new ArrayList<String>(globkeys1);
                        String val = nameList.get(position);
                        Log.i("clicked",val);
                        Bundle b1 = new Bundle();
                        Intent intent1 = new Intent(getApplicationContext(), MainTabbedActivity.class);
                        b1.putString("Esymbol",val);
                        String message = val;
                        intent1.putExtra(EXTRA_MESSAGE, message);
                        intent1.putExtras(b1);
                        startActivityForResult(intent1, 2);
                    }});

                }
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
//        SharedPreferences.Editor editor = sharedPref.edit();
//        editor.clear();
//        editor.commit();
        Map<String,?> keys = sharedPref.getAll();
//        Log.i("hi",keys.toString());
        ArrayList<String> symList = new ArrayList<String>();
        ArrayList<String> priceList = new ArrayList<String>();
        ArrayList<String> changeList = new ArrayList<String>();
        String[] symarray;
        String[] pricearray;
        String[] changearray;
        for(Map.Entry<String,?> entry : keys.entrySet()){
            String key = entry.getKey();
            String value = entry.getValue().toString();
            String[] text = gson.fromJson(value,String[].class);
            symList.add(text[0]);
            priceList.add(text[1]);
            changeList.add(text[2]);
        }
        symarray = symList.toArray(new String[symList.size()]);
        pricearray = priceList.toArray(new String[priceList.size()]);
        changearray = changeList.toArray(new String[changeList.size()]);
        CustomFavAdapter favadapter = new CustomFavAdapter(getApplicationContext(),symarray,pricearray,changearray);
        ListView listView = (ListView)findViewById(R.id.favlist);
        registerForContextMenu(listView);
        listView.setAdapter(favadapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = sharedPref.edit();
                Map<String,?> keys = sharedPref.getAll();
                globkeys1 = keys.keySet();
                List<String> nameList = new ArrayList<String>(globkeys1);
                String val = nameList.get(position);
                Log.i("clicked",val);
                Bundle b1 = new Bundle();
                Intent intent1 = new Intent(getApplicationContext(), MainTabbedActivity.class);
                b1.putString("Esymbol",val);
                String message = val;
                intent1.putExtra(EXTRA_MESSAGE, message);
                intent1.putExtras(b1);
                startActivityForResult(intent1, 2);
            }});

    }


    public void sendMessage(View view) throws ExecutionException, InterruptedException {
        // Do something in response to button

        Bundle b = new Bundle();

        Intent intent = new Intent(this, MainTabbedActivity.class);
        AutoCompleteTextView editText = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);

        if (editText.getText().toString().trim().length() == 0) {
            int duration = Toast.LENGTH_SHORT;
            Toast.makeText(getApplicationContext(), "Please enter a stock name or symbol", duration).show();
        } else {

            b.putString("Esymbol", editText.getText().toString());
            String message = editText.getText().toString();
            intent.putExtra(EXTRA_MESSAGE, message);
            intent.putExtras(b);
            startActivityForResult(intent, 2);
        }
    }

//    public void Refresh(View view) throws ExecutionException, InterruptedException {
//        // Do something in response to button
//
//        sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
//        SharedPreferences.Editor editor = sharedPref.edit();
//        Map<String,?> keys = sharedPref.getAll();
//        globkeys1 = keys.keySet();
//        List<String> nameList = new ArrayList<String>(globkeys1);
//        if(nameList != null){
//
//        }
//        String val = nameList.get(position);

//        Bundle b = new Bundle();
//
//        Intent intent = new Intent(this, MainTabbedActivity.class);
//        EditText editText = (EditText) findViewById(R.id.editText);
//        b.putString("Esymbol",editText.getText().toString());
//        String message = editText.getText().toString();
//        intent.putExtra(EXTRA_MESSAGE, message);
//        intent.putExtras(b);
//        startActivityForResult(intent, 2);
//    }



//    public int checkorder(){
//
//        return posorder;
//    }
}