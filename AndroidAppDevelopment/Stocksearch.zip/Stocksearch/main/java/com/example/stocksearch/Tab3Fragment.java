package com.example.stocksearch;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.lang.reflect.Array;
import java.util.ArrayList;

import static android.content.ContentValues.TAG;
import static com.example.stocksearch.R.layout.fragment_tab3;


/**
 * A simple {@link Fragment} subclass.
 */
public class Tab3Fragment extends Fragment {


    public Tab3Fragment() {
        // Required empty public constructor
    }
    private RequestQueue mRequestQueue;
    private StringRequest stringRequest;
    static JSONArray object;
    View v;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Bundle b2 = getArguments();
        if (b2 != null) {
            String symstring = b2.getString("Esymbol");   // full file name
            String[] parts = symstring.split("-"); // String array, each element is text between dots
            String beforeFirstDot = parts[0];
            final String symbol = beforeFirstDot;
            final String API_news = "http://homework8vpravi-env.us-east-1.elasticbeanstalk.com/index.php?newsvalue="+symbol;
            v = (View) inflater.inflate(fragment_tab3, container, false);
            mRequestQueue = Singleton.getInstance(getActivity().getApplicationContext()).getRequestQueue(getActivity().getApplicationContext());
            stringRequest = new StringRequest(Request.Method.GET, API_news, new Response.Listener<String>() {
                public void onResponse(String response) {
//
                    try {
                        object = (JSONArray) new JSONTokener(response).nextValue();
                        JSONArray titles = (JSONArray) object.get(0);
                        JSONArray links = (JSONArray) object.get(1);
                        JSONArray authors = (JSONArray) object.get(3);
                        JSONArray dates = (JSONArray) object.get(2);

                        String[] titlesarray = new String[5];
                        String[] authorarray = new String[5];
                        String[] datesarray = new String[5];
                        String[] linksarray = new String[5];
                        for (int i = 0; i < titles.length(); i++) {
                            String tempnews = titles.get(i).toString();
                            String tempauthor = authors.get(i).toString();
                            String tempdates = dates.get(i).toString();
                            String templinks = links.get(i).toString();
                            titlesarray[i] = tempnews;
                            authorarray[i] = tempauthor;
                            datesarray[i] = tempdates;
                            linksarray[i] = templinks;
                        }

                        CustomNewsAdapter adapter = new CustomNewsAdapter(getActivity(), titlesarray, authorarray, datesarray, linksarray);
                        ListView listView = (ListView) v.findViewById(R.id.news_list);

                        final String[] larray = linksarray;

                        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                Uri uri = Uri.parse(larray[position]);
                                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                startActivity(intent);

                            }
                        });

                        listView.setAdapter(adapter);
                    } catch (JSONException e) {
                    }
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    int duration = Toast.LENGTH_LONG;
                    Toast.makeText(getActivity(), "Error! Cant get News Data", duration).show();
                }
            });
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    10000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            mRequestQueue.add(stringRequest);

        }
        return v;
    }
}
