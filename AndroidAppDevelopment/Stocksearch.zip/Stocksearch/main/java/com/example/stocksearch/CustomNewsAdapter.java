package com.example.stocksearch;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.json.JSONArray;

/**
 * Created by Vishnupriya on 11/25/17.
 */

public class CustomNewsAdapter extends BaseAdapter {

    String [] titlesarray;
    String[] authorarray;
    String[] datesarray;
    String[] linksarray;
    LayoutInflater infl;

    public CustomNewsAdapter(Context context, String[] a,String[] b,String[] c,String[] d) {
        titlesarray = a;
        authorarray = b;
        datesarray = c;
        linksarray = d;
        infl=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public int getCount() {
        return titlesarray.length;
    }

    @Override
    public Object getItem(int i) {
        return titlesarray[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        View v = infl.inflate(R.layout.activity_listview,null);

        TextView title = (TextView)v.findViewById(R.id.news);
        TextView author = (TextView)v.findViewById(R.id.author);
        TextView dates = (TextView)v.findViewById(R.id.date);
        title.setText(titlesarray[position]);
        author.setText(authorarray[position]);
        dates.setText(datesarray[position]);

        return v;
    }
}
