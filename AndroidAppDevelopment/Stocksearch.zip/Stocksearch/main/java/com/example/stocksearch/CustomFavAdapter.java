package com.example.stocksearch;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Vishnupriya on 11/27/17.
 */

public class CustomFavAdapter extends BaseAdapter {

    String [] titlesarray;
    String[] authorarray;
    String[] datesarray;
    String[] linksarray;
    LayoutInflater infl;

    public CustomFavAdapter(Context context, String[] a, String[] b, String[] c) {
        titlesarray = a;
        authorarray = b;
        datesarray = c;
        infl=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public int getCount() {
        return titlesarray.length;
    }

    @Override
    public Object getItem(int i) {
        return titlesarray[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        View v = infl.inflate(R.layout.list_view,null);

        TextView title = (TextView)v.findViewById(R.id.symval);
        TextView author = (TextView)v.findViewById(R.id.priceval);
        TextView dates = (TextView)v.findViewById(R.id.changeval);
        title.setText(titlesarray[position]);
        author.setText(authorarray[position]);
        String chnagestr = datesarray[position];
        String[] parts = chnagestr.split("\\("); // String array, each element is text between dots
        String beforeFirst= parts[0];
        Float change = Float.valueOf(beforeFirst);
        if (change<0) {
            dates.setText(datesarray[position]);
            dates.setTextColor(Color.RED);
//            arrow.setImageResource(R.drawable.red_down);
        }else if(change>0){
            dates.setText(datesarray[position]);
            dates.setTextColor(Color.GREEN);
//            arrow.setImageResource(R.drawable.green_arrow_up);
        }

        return v;
    }
}
